-- Insert values to Dept table
INSERT INTO Dept VALUES
('A00','Spiffy Computer Service DIV.','000010','A00');
INSERT INTO Dept VALUES
('B01','Planning','000020','A00');
INSERT INTO Dept VALUES
('C01','Information Centre','000030','A00');
INSERT INTO Dept VALUES
('D01','Development Centre',null,'A00');
INSERT INTO Dept VALUES
('D11','Manufacturing Systems','000060','D01');
INSERT INTO Dept VALUES
('D21','Administration Systems','000070','D01');
INSERT INTO Dept VALUES
('E01','Support Services','000050','A00');
INSERT INTO Dept VALUES
('E11','Operations','000090','E01');
INSERT INTO Dept VALUES
('E21','Software Support','000100','E01');