-- Insert values to Emp table
INSERT INTO Emp VALUES
('000010','Christine','I','Haas','A00','3978','2000-01-01','Pres',18,'F','1968-08-14',312750,1000,4220);                                             
INSERT INTO Emp VALUES
('000020','Michael','L','Thompson','B01','3476','2008-10-10','Manager',18,'M','1983-02-02',161250,800,3000);                                         
INSERT INTO Emp VALUES
('000030','Sally','A','Kwan','C01','4738','2010-05-05','Manager',20,'F','1980-05-11',158250,800,3060);                                         
INSERT INTO Emp VALUES
('000050','John','B','Geyer','E01','6789','2003-08-17','Manager',16,'M','1975-09-15',160175,800,3214);                                         
INSERT INTO Emp VALUES
('000060','Irving','F','Stern','D11','6423','2003-09-14','Manager',16,'M','1975-07-07',155555,600,2580);                                          
INSERT INTO Emp VALUES
('000070','Eva','D','Pulaski','D21','7831','2000-09-30','Manager',16,'F','1983-05-26',156170,700,2893);                                          
INSERT INTO Emp VALUES
('000090','Eileen','W','Henderson','E11','5498','2002-08-15','Manager',16,'F','1976-05-15',149750,600,2380);                                          
INSERT INTO Emp VALUES
('000100','Theodore','Q','Spenser','E21','0972','2006-06-19','Manager',14,'M','1989-12-18',146150,500,2092);                                          
INSERT INTO Emp VALUES
('000110','Vincenzo','G','Lucchesi','A00','3490','2003-05-16','Salesrep',19,'M','1983-11-05',156500,900,3720);                                          
INSERT INTO Emp VALUES
('000120','Sean',' ','Oconnell','A00','2167','2003-10-05','Programmer',14,'M','1982-10-18',99250,600,2340);                                          
INSERT INTO Emp VALUES
('000130','Dolores','M','Quintana','C01','4578','2006-07-28','Analyst',16,'F','1985-09-15',93800,500,1904);                                          
INSERT INTO Emp VALUES
('000140','Heather','A','Nicholls','C01','1793','2006-12-15','Analyst',18,'F','1986-10-19',88420,600,2274);                                          
INSERT INTO Emp VALUES
('000150','Bruce',' ','Adamson','D11','4510','2007-02-12','Designer',16,'M','1982-05-17',95280,500,2022);                                         
INSERT INTO Emp VALUES
('000160','Elizabeth','R','Pianka','D11','3782','2009-10-11','Designer',17,'F','1987-04-12',92250,400,1780);                                          
INSERT INTO Emp VALUES
('000170','Masatoshi','J','Yoshimura','D11','2890','2008-01-01','Designer',16,'M','1986-01-05',84680,500,1974);                                          
INSERT INTO Emp VALUES
('000180','Marilyn','S','Scoutten','D11','1682','2003-07-07','Designer',17,'F','1982-02-21',81340,500,1707);                                          
INSERT INTO Emp VALUES
('000190','James','H','Walker','D11','2986','2012-07-26','Designer',16,'M','1992-06-25',70450,400,1636);                                          
INSERT INTO Emp VALUES
('000200','David',' ','Brown','D11','4501','2008-03-03','Designer',16,'M','1986-05-29',77740,600,2217);                                          
INSERT INTO Emp VALUES
('000210','William','T','Jones','D11','0942','2009-04-11','Designer',17,'M','1983-03-23',88270,400,1462);                                         
INSERT INTO Emp VALUES
('000220','Jennifer','K','Lutz','D11','0672','2004-08-29','Designer',18,'F','1979-03-19',89840,600,2387);                                            
INSERT INTO Emp VALUES
('000230','James','J','Jefferson','D21','2094','2011-11-21','Programmer',14,'M','1985-05-30',62180,400,1774);                                         
INSERT INTO Emp VALUES
('000240','Salvatore','M','Marino','D21','3780','2009-12-05','Programmer',17,'M','1984-03-31',68760,600,2301);                                          
INSERT INTO Emp VALUES
('000250','Daniel','S','Smith','D21','0961','2009-10-30','Programmer',15,'M','1982-11-12',59180,400,1534);                                          
INSERT INTO Emp VALUES
('000260','Sybil','V','Johnson','D21','8953','2005-09-11','Programmer',16,'F','1986-10-05',57250,300,1380);                                          
INSERT INTO Emp VALUES
('000270','03ia','L','Perez','D21','9001','2009-09-30','Programmer',15,'F','1983-05-26',57380,500,2190);                                          
INSERT INTO Emp VALUES
('000280','Ethel','R','Schneider','E11','8997','2009-03-24','Operator',17,'F','1986-03-28',86250,500,2100);                                         
INSERT INTO Emp VALUES
('000290','John','R','Parker','E11','4502','2006-05-30','Operator',12,'M','1988-07-09',75340,300,1227);                                          
INSERT INTO Emp VALUES
('000300','Philip','X','Smith','E11','2095','2007-06-19','Operator',14,'M','1986-10-27',77750,400,1420);                                          
INSERT INTO Emp VALUES
('000310','Maude','F','Setright','E11','3332','2001-09-12','Operator',12,'F','1981-04-21',75900,300,1272);                                        
INSERT INTO Emp VALUES
('000320','Ramlal','V','Mehta','E21','9990','2005-07-07','Fieldrep',16,'M','1982-08-11',99950,400,1596);                                         
INSERT INTO Emp VALUES
('000330','Wing',' ','Lee','E21','2103','1999-02-23','Fieldrep',14,'M','1981-07-18',95370,500,2030);                                          
INSERT INTO Emp VALUES
('000340','Jason','R','Gounot','E21','5698','1999-05-05','Fieldrep',16,'M','1976-05-17',123840,500,1907);